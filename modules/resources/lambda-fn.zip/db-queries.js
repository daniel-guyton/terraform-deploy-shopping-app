"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateCartQuantity = exports.deleteProductFromCart = exports.getProductsByProductId = exports.getCartItemsByCartId = exports.getCartIdByUserId = exports.updateOrInsertCartItem = exports.getProducts = void 0;
const knex_1 = require("knex");
const knex = (0, knex_1.default)({
    client: 'mysql',
    connection: {
        ssl: {
            rejectUnauthorized: false
        },
        host: process.env.DB_ENDPOINT,
        user: 'tstdb01',
        password: 'tstdb01234',
        database: 'mydb'
    }
});
const updateCartQuantity = (quantity, product_id) => {
    console.log(quantity);
    console.log(product_id);
    return knex('cart_item')
        .update('qty', quantity)
        .where('product_id', product_id);
};
exports.updateCartQuantity = updateCartQuantity;
const deleteProductFromCart = (id) => {
    console.log(id);
    return knex('cart_item')
        .where('product_id', id)
        .del();
};
exports.deleteProductFromCart = deleteProductFromCart;
const getProducts = () => {
    return knex('products')
        .select();
};
exports.getProducts = getProducts;
const updateOrInsertCartItem = (payload) => {
    return knex('cart_item')
        .insert(payload)
        .onConflict('product_id')
        .merge({ qty: knex.raw('?? + 1', 'qty') });
};
exports.updateOrInsertCartItem = updateOrInsertCartItem;
const getCartIdByUserId = (user_id) => {
    return knex('cart')
        .join('users', 'users.id', 'cart.user_id')
        .where('user_id', user_id)
        .select('cart.id');
};
exports.getCartIdByUserId = getCartIdByUserId;
const getCartItemsByCartId = (cart_id) => {
    return knex('cart_item')
        .select('*')
        .where('cart_id', cart_id);
};
exports.getCartItemsByCartId = getCartItemsByCartId;
const getProductsByProductId = (product_id) => {
    return knex('products')
        .select()
        .where('id', product_id);
};
exports.getProductsByProductId = getProductsByProductId;
