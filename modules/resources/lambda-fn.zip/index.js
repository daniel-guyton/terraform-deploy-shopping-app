"use strict";
/* eslint-disable camelcase */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const AWS = require("aws-sdk");
const db_1 = require("./db");
AWS.config.update({ region: 'ap-southeast-2' });
// eslint-disable-next-line no-unused-vars
const handler = (event, context, callback) => __awaiter(void 0, void 0, void 0, function* () {
    console.log('Received event:', JSON.stringify(event, null, 2));
    let body;
    let payload;
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, PUT, GET, OPTIONS',
        'Access-Control-Allow-Headers': '*',
        'Cache-Control': 'max-age=0, no-store, must-revalidate',
        Pragma: 'no-cache',
        Expires: 0
    };
    const data = {
        multiValueHeaders: {},
        isBase64Encoded: false,
        statusCode: 200,
        headers,
        body: ''
    };
    try {
        switch (true) {
            case event.httpMethod == 'POST':
                if (event.body !== null && event.body !== undefined) {
                    payload = JSON.parse(event.body);
                }
                yield (0, db_1.updateOrInsertCartItem)({ cart_id: 1, product_id: payload.id, qty: 1 });
                body = `Succesfully posting ${event.body}`; // POST /product
                break;
            case event.httpMethod == 'GET' && event.path == '/getUserCart':
                const cartId = yield (0, db_1.getCartIdByUserId)(2);
                const listOfCartItems = yield (0, db_1.getCartItemsByCartId)(cartId[0].id);
                body = yield Promise.all(listOfCartItems.map((item) => __awaiter(void 0, void 0, void 0, function* () {
                    return ({
                        product: Object.assign.apply({}, yield (0, db_1.getProductsByProductId)(item.product_id)),
                        qty: item.qty
                    });
                })));
                break;
            case event.httpMethod == 'GET':
                body = yield (0, db_1.getProducts)(); // GET product
                break;
            case event.httpMethod == 'OPTIONS':
                context.done(undefined, data);
                break;
            default:
                throw new Error(`Unsupported route: "${event.httpMethod}"`);
        }
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({
                message: `Successfully finished operation: "${event.httpMethod}"`,
                body
            })
        };
    }
    catch (e) {
        console.error(e);
        return {
            statusCode: 400,
            body: JSON.stringify({
                message: 'Failed to perform operation.',
                errorMsg: e.message
            })
        };
    }
});
exports.handler = handler;
