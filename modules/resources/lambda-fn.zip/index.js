"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
/* eslint-disable camelcase */
const knex_1 = require("knex");
const AWS = require("aws-sdk");
const knex = (0, knex_1.default)({
    client: 'mysql',
    connection: {
        ssl: {
            rejectUnauthorized: false
        },
        host: process.env.DB_ENDPOINT,
        user: 'tstdb01',
        password: 'tstdb01234',
        database: 'mydb'
    }
});
AWS.config.update({ region: 'ap-southeast-2' });
const getProducts = () => {
    return knex('products')
        .select();
};
const updateOrInsertCartItem = (payload) => {
    return knex('cart_item')
        .insert(payload)
        .onConflict('product_id')
        .merge({ qty: knex.raw('?? + 1', 'qty') });
};
const getCartIdByUserId = (user_id) => {
    return knex('cart')
        .join('users', 'users.id', 'cart.user_id')
        .where('user_id', user_id)
        .select('cart.id');
};
const getCartItemsByCartId = (cart_id) => {
    return knex('cart_item')
        .select('*')
        .where('cart_id', cart_id);
};
const getProductsByProductId = (product_id) => {
    return knex('products')
        .select()
        .where('id', product_id);
};
// eslint-disable-next-line no-unused-vars
const handler = (event, context, callback) => __awaiter(void 0, void 0, void 0, function* () {
    console.log('Received event:', JSON.stringify(event, null, 2));
    let body;
    let payload;
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, PUT, GET, OPTIONS',
        'Access-Control-Allow-Headers': '*',
        'Cache-Control': 'max-age=0, no-store, must-revalidate',
        Pragma: 'no-cache',
        Expires: 0
    };
    const data = {
        multiValueHeaders: {},
        isBase64Encoded: false,
        statusCode: 200,
        headers,
        body: ''
    };
    try {
        switch (true) {
            case event.httpMethod == 'POST':
                if (event.body !== null && event.body !== undefined) {
                    payload = JSON.parse(event.body);
                }
                yield updateOrInsertCartItem({ cart_id: 1, product_id: payload.id, qty: 1 });
                body = `Succesfully posting ${event.body}`; // POST /product
                break;
            case event.httpMethod == 'GET' && event.path == '/getUserCart':
                const cartId = yield getCartIdByUserId(2);
                const listOfCartItems = yield getCartItemsByCartId(cartId[0].id);
                body = yield Promise.all(listOfCartItems.map((item) => __awaiter(void 0, void 0, void 0, function* () {
                    return ({
                        product: Object.assign.apply({}, yield getProductsByProductId(item.product_id)),
                        qty: item.qty
                    });
                })));
                break;
            case event.httpMethod == 'GET':
                body = yield getProducts(); // GET product
                break;
            case event.httpMethod == 'OPTIONS':
                context.done(undefined, data);
                break;
            default:
                throw new Error(`Unsupported route: "${event.httpMethod}"`);
        }
        console.log(event.body);
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({
                message: `Successfully finished operation: "${event.httpMethod}"`,
                body
            })
        };
    }
    catch (e) {
        console.error(e);
        return {
            statusCode: 400,
            body: JSON.stringify({
                message: 'Failed to perform operation.',
                errorMsg: e.message
            })
        };
    }
});
exports.handler = handler;
